from django.apps import AppConfig


class PlantNurseryAppConfig(AppConfig):
    name = 'plant_nursery_app'
